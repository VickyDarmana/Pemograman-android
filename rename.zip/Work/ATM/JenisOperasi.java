package ATM;

public enum JenisOperasi {
   CHECK_BALANCE,
   DEPOSIT,
   TRANSACTION_HISTORY,
   LOGOUT,
   TRANSFER,
   WITHDRAW
}
