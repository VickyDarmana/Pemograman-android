letakkan paper anda ke dalam folder Paper ini.
