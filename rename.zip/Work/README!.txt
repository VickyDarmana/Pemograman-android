To make sure the program runs in your pc, make sure to change the path of the bankdetails.csv

How to:

1. Go to App.Java file and go to line 136

2. You will see something like this 
String csvFile = "D:/Work/BankAccountJoki/Work/Paper/bankdetails.csv";

3. Change the pathing of the bankdetails.csv according to your laptop/pc/device
Example:
String csvFile = "D:/College/TugasKu/Work/Paper/bankdetails.csv
